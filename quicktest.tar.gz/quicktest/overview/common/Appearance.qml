pragma Singleton
pragma ComponentBehavior: Bound

import QtQuick
import Quickshell
import Quickshell.Io
import "functions"
import "." as Common

Singleton {
    id: root
    
    // Read pywal colors from cache using Process
    Process {
        id: pywalProcess
        command: ["cat", "/home/" + Quickshell.env("USER") + "/.cache/wal/colors.json"]
        running: true
        
        stdout: SplitParser {
            id: pywalOutput
            onRead: data => {
                if (data.trim()) {
                    pywalProcess.outputData += data + "\n";
                }
            }
        }
        
        property string outputData: ""
        property bool dataReady: false
        
        onRunningChanged: {
            if (!running && outputData) {
                dataReady = true;
            }
        }
        
        function refresh() {
            outputData = "";
            dataReady = false;
            running = false;
            running = true;
        }
    }
    
    // File watcher to detect changes to colors.json
    Process {
        id: colorWatcher
        command: ["sh", "-c", "inotifywait -m -e modify $HOME/.cache/wal/colors.json"]
        running: true
        
        stdout: SplitParser {
            onRead: () => pywalProcess.refresh()
        }
    }
    
    property var pywalData: {
        if (pywalProcess.dataReady && pywalProcess.outputData) {
            try {
                return JSON.parse(pywalProcess.outputData);
            } catch (e) {
                // Silently use fallback if parsing fails
            }
        }
        return {
            special: { background: "#0C0417", foreground: "#beaeca", cursor: "#beaeca" },
            colors: {
                color0: "#0C0417", color1: "#5C4260", color2: "#926D7A", color3: "#2F2296",
                color4: "#502F96", color5: "#64569D", color6: "#524EC4", color7: "#beaeca",
                color8: "#85798d", color9: "#5C4260", color10: "#926D7A", color11: "#2F2296",
                color12: "#502F96", color13: "#64569D", color14: "#524EC4", color15: "#beaeca"
            }
        };
    }
    
    property QtObject m3colors: QtObject {
        property bool darkmode: true
        property color m3primary: pywalData.colors.color5
        property color m3onPrimary: pywalData.colors.color0
        property color m3primaryContainer: pywalData.colors.color4
        property color m3onPrimaryContainer: pywalData.colors.color15
        property color m3secondary: pywalData.colors.color6
        property color m3onSecondary: pywalData.colors.color0
        property color m3secondaryContainer: pywalData.colors.color8
        property color m3onSecondaryContainer: pywalData.colors.color15
        property color m3background: pywalData.special.background
        property color m3onBackground: pywalData.colors.color15
        property color m3surface: pywalData.special.background
        property color m3surfaceContainerLow: pywalData.colors.color0
        property color m3surfaceContainer: pywalData.colors.color8
        property color m3surfaceContainerHigh: pywalData.colors.color1
        property color m3surfaceContainerHighest: pywalData.colors.color2
        property color m3onSurface: pywalData.colors.color15
        property color m3surfaceVariant: pywalData.colors.color8
        property color m3onSurfaceVariant: pywalData.colors.color7
        property color m3inverseSurface: pywalData.colors.color15
        property color m3inverseOnSurface: pywalData.colors.color0
        property color m3outline: pywalData.colors.color8
        property color m3outlineVariant: pywalData.colors.color8
        property color m3shadow: pywalData.colors.color0
    }
    
    property QtObject animation
    property QtObject animationCurves
    property QtObject colors
    property QtObject rounding
    property QtObject font
    property QtObject sizes

    colors: QtObject {
        property color colSubtext: m3colors.m3outline
        property color colLayer0: m3colors.m3background
        property color colOnLayer0: m3colors.m3onBackground
        property color colLayer0Border: ColorUtils.mix(root.m3colors.m3outlineVariant, colLayer0, 0.4)
        property color colLayer1: m3colors.m3surfaceContainerLow
        property color colOnLayer1: m3colors.m3onSurfaceVariant
        property color colOnLayer1Inactive: ColorUtils.mix(colOnLayer1, colLayer1, 0.45)
        property color colLayer1Hover: ColorUtils.mix(colLayer1, colOnLayer1, 0.92)
        property color colLayer1Active: ColorUtils.mix(colLayer1, colOnLayer1, 0.85)
        property color colLayer2: m3colors.m3surfaceContainer
        property color colOnLayer2: m3colors.m3onSurface
        property color colLayer2Hover: ColorUtils.mix(colLayer2, colOnLayer2, 0.90)
        property color colLayer2Active: ColorUtils.mix(colLayer2, colOnLayer2, 0.80)
        property color colPrimary: m3colors.m3primary
        property color colOnPrimary: m3colors.m3onPrimary
        property color colSecondary: m3colors.m3secondary
        property color colSecondaryContainer: m3colors.m3secondaryContainer
        property color colOnSecondaryContainer: m3colors.m3onSecondaryContainer
        property color colTooltip: m3colors.m3inverseSurface
        property color colOnTooltip: m3colors.m3inverseOnSurface
        property color colShadow: ColorUtils.transparentize(m3colors.m3shadow, 0.7)
        property color colOutline: m3colors.m3outline
    }

    rounding: QtObject {
        property int unsharpen: 2
        property int verysmall: 8
        property int small: 12
        property int normal: 17
        property int large: 23
        property int full: 9999
        property int screenRounding: large
        property int windowRounding: 18
    }

    font: QtObject {
        property QtObject family: QtObject {
            property string main: "sans-serif"
            property string title: "sans-serif"
            property string expressive: "sans-serif"
        }
        property QtObject pixelSize: QtObject {
            property int smaller: 12
            property int small: 15
            property int normal: 16
            property int larger: 19
            property int huge: 22
        }
    }

    animationCurves: QtObject {
        readonly property list<real> expressiveDefaultSpatial: [0.38, 1.21, 0.22, 1.00, 1, 1]
        readonly property list<real> expressiveEffects: [0.34, 0.80, 0.34, 1.00, 1, 1]
        readonly property list<real> emphasizedDecel: [0.05, 0.7, 0.1, 1, 1, 1]
        readonly property real expressiveDefaultSpatialDuration: 500
        readonly property real expressiveEffectsDuration: 200
    }

    animation: QtObject {
        property QtObject elementMove: QtObject {
            property int duration: animationCurves.expressiveDefaultSpatialDuration
            property int type: Easing.BezierSpline
            property list<real> bezierCurve: animationCurves.expressiveDefaultSpatial
            property Component numberAnimation: Component {
                NumberAnimation {
                    duration: root.animation.elementMove.duration
                    easing.type: root.animation.elementMove.type
                    easing.bezierCurve: root.animation.elementMove.bezierCurve
                }
            }
        }

        property QtObject elementMoveEnter: QtObject {
            property int duration: 400
            property int type: Easing.BezierSpline
            property list<real> bezierCurve: animationCurves.emphasizedDecel
            property Component numberAnimation: Component {
                NumberAnimation {
                    duration: root.animation.elementMoveEnter.duration
                    easing.type: root.animation.elementMoveEnter.type
                    easing.bezierCurve: root.animation.elementMoveEnter.bezierCurve
                }
            }
        }

        property QtObject elementMoveFast: QtObject {
            property int duration: animationCurves.expressiveEffectsDuration
            property int type: Easing.BezierSpline
            property list<real> bezierCurve: animationCurves.expressiveEffects
            property Component numberAnimation: Component {
                NumberAnimation {
                    duration: root.animation.elementMoveFast.duration
                    easing.type: root.animation.elementMoveFast.type
                    easing.bezierCurve: root.animation.elementMoveFast.bezierCurve
                }
            }
        }
    }

    sizes: QtObject {
        property real elevationMargin: 10
    }
}
