import QtQuick
import QtQuick.Layouts
import "../../theming" as T

// ── WallpaperButton ───────────────────────────────────────────────────────────
// Sits in its own pill (split mode) — mirrors the style of ReloadButton.
// Emits toggleWallpaper so the parent StatusBarRoot owns the open/close state.
// ─────────────────────────────────────────────────────────────────────────────
Rectangle {
    id: root

    property bool barShape:      false
    property bool wallpaperOpen: false

    signal toggleWallpaper()

    implicitHeight: T.Theme.pillHeight
    implicitWidth:  innerRow.implicitWidth + 24
    radius: T.Theme.radius(barShape)

    // Always pillBg — accent tint is an overlay, not a base-color swap
    color: T.Theme.pillBg

    Behavior on radius { NumberAnimation { duration: T.Theme.animSlow; easing.type: Easing.OutCubic } }

    // Accent tint overlay when open; hover highlight otherwise; transparent at rest
    Rectangle {
        anchors.fill: parent
        radius: parent.radius
        color: ma.containsMouse
            ? (root.wallpaperOpen
                ? T.Theme.pw(T.Theme.pal?.colors?.color9, 0.30)
                : T.Theme.hoverFull)
            : (root.wallpaperOpen
                ? T.Theme.pw(T.Theme.pal?.colors?.color9, 0.18)
                : "transparent")
        Behavior on color { ColorAnimation { duration: T.Theme.animFast } }
    }

    RowLayout {
        id: innerRow
        anchors.centerIn: parent
        spacing: 6

        Image {
            source: "../../theming/icons/wall.svg"
            width: 16; height: 16
            fillMode: Image.PreserveAspectFit
        }

        Text {
            text: root.wallpaperOpen ? "Close" : "Wallpaper"
            color: root.wallpaperOpen ? T.Theme.color1 : T.Theme.fg
            font {
                pixelSize: 11
                weight: Font.Medium
                family: T.Theme.fontFamily
            }
            Behavior on color { ColorAnimation { duration: T.Theme.animFast } }
        }
    }

    MouseArea {
        id: ma
        anchors.fill: parent
        hoverEnabled: true
        cursorShape: Qt.PointingHandCursor
        onClicked: root.toggleWallpaper()
    }
}
