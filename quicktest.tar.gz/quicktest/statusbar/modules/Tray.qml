// Tray.qml — Quickshell
//
// • Left-click   → activate()
// • Right-click  → native DBus menu
// • Middle-click → secondaryActivate()
// • Hover        → ✕ kill badge

import Quickshell
import Quickshell.Io
import Quickshell.Widgets
import Quickshell.Services.SystemTray
import Quickshell.DBusMenu
import QtQuick
import "../../theming" as T

Item {
    id: root

    property var  parentWindow: null
    property bool barShape:     false

    readonly property var theme: T.Theme
    readonly property int itemCount: SystemTray.items.values.length

    implicitWidth:  itemCount * 26 + Math.max(0, itemCount - 1) * 4 + 24
    implicitHeight: root.theme?.pillHeight ?? 24

    Rectangle {
        anchors.fill: parent
        radius: root.theme?.radius(root.barShape) ?? 12
        color:  root.theme?.pillBg ?? "transparent"
        Behavior on color  { ColorAnimation  { duration: root.theme?.animFast  ?? 150 } }
        Behavior on radius { NumberAnimation { duration: root.theme?.animSlow ?? 250; easing.type: Easing.OutCubic } }
    }

    // ── Kill process — root-level, explicitly restarted each use ─────────────
    Process {
        id: killProc
        running: false
        stdout: SplitParser { onRead: function(line) { console.log("[kill] " + line) } }
        stderr: SplitParser { onRead: function(line) { console.log("[kill] ERR " + line) } }
        onExited: function(code) { console.log("[kill] exit=" + code) }
    }

    function doKill(sni) {
        // The SNI object path is like /org/kde/StatusNotifierItem
        // The DBus service that registered it is the unique name, e.g. :1.773
        // Quickshell exposes this as sni.id for some items, but for others
        // (like Chrome) it sets id to something app-defined like "chrome_status_icon_1".
        //
        // The ONLY reliable way to find the process is:
        //   1. Ask DBus daemon: GetConnectionUnixProcessID(service_name)
        //      The service name is available from the SNI item via its DBus path.
        //      Quickshell's SystemTrayItem has no direct .pid property, but
        //      the service name is the first part of sni.id when it's a unique name
        //      (starts with ':'), or we look it up via gdbus.
        //
        // Strategy:
        //   A) gdbus call to get PID from the DBus unique name (most reliable)
        //   B) /proc scan matching argv[0] basename against cleaned-up app name
        //   C) pgrep -x -i as last resort

        var rawId    = (sni?.id    ?? "")
        var rawTitle = (sni?.title ?? "")

        console.log("[kill] sni.id=" + rawId + " sni.title=" + rawTitle)

        // Extract the DBus unique name. It may be directly in rawId (":1.773")
        // or embedded as the service part of the SNI id string.
        // Quickshell SNI ids look like "org.kde.StatusNotifierHost-:1.773-0"
        // or just ":1.773" or "discord" or "chrome_status_icon_1".
        var dbusName = ""
        var colonMatch = rawId.match(/(:[0-9]+\.[0-9]+)/)
        if (colonMatch) dbusName = colonMatch[1]

        function san(s) { return s.replace(/[^a-zA-Z0-9_-]/g, "") }

        // Build name candidates for fallback matching
        // Use title first (more likely to match process name), then id segments
        var titleClean = san(rawTitle.toLowerCase())
        // Drop generic suffixes from id: "chrome_status_icon_1" → "chrome"
        var idClean    = san(rawId.split(".").pop().toLowerCase().replace(/_status_icon.*$/, "").replace(/_[0-9]+$/, ""))

        var names = []
        if (titleClean !== "") names.push(titleClean)
        if (idClean !== "" && idClean !== titleClean) names.push(idClean)

        console.log("[kill] dbusName=" + dbusName + " names=" + names.join(","))

        // ── Script ────────────────────────────────────────────────────────────
        // Part A: resolve PID via DBus daemon (works for ANY tray app regardless of name)
        var partA = dbusName !== "" ? [
            '# A: DBus PID lookup for ' + dbusName,
            'pid=$(gdbus call --session \\',
            '  --dest org.freedesktop.DBus \\',
            '  --object-path /org/freedesktop/DBus \\',
            '  --method org.freedesktop.DBus.GetConnectionUnixProcessID \\',
            '  "' + dbusName + '" 2>/dev/null | tr -d "()" | tr -d " ")',
            'echo "dbus pid=$pid"',
            'if [ -n "$pid" ] && [ "$pid" -gt 0 ] 2>/dev/null; then',
            '  kill -9 "$pid" 2>/dev/null && exit 0',
            'fi'
        ].join("\n") : '# A: no DBus unique name available'

        // Part B: /proc argv[0] basename scan
        var casePatterns = names.length > 0
            ? names.map(function(n) { return '"' + n + '"' }).join("|")
            : '"__nomatch__"'

        var partB = [
            '# B: /proc argv[0] basename scan',
            'found=""',
            'for f in /proc/[0-9]*/cmdline; do',
            '  [ -r "$f" ] || continue',
            '  pid="${f%/cmdline}"; pid="${pid##*/}"',
            '  argv0=$(tr "\\0" "\\n" < "$f" 2>/dev/null | head -1)',
            '  base=$(basename "$argv0" 2>/dev/null | tr "[:upper:]" "[:lower:]")',
            '  case "$base" in',
            '    ' + casePatterns + ')',
            '      echo "proc hit pid=$pid base=$base"',
            '      kill -9 "$pid" 2>/dev/null',
            '      found=1 ;;',
            '  esac',
            'done',
            '[ -n "$found" ] && exit 0'
        ].join("\n")

        // Part C: pgrep fallback
        var partC = names.length > 0 ? [
            '# C: pgrep fallback'
        ].concat(names.map(function(n) {
            return 'pids=$(pgrep -x -i "' + n + '" 2>/dev/null)\n' +
                   'echo "pgrep ' + n + ' -> $pids"\n' +
                   '[ -n "$pids" ] && { for p in $pids; do kill -9 "$p" 2>/dev/null; done; exit 0; }'
        })).join("\n") : '# C: no name candidates'

        var script = [partA, partB, partC, 'exit 0'].join("\n\n")

        console.log("[kill] script:\n" + script)

        killProc.running = false
        killProc.command = ["sh", "-c", script]
        killProc.running = true
    }

    Row {
        anchors.centerIn: parent
        spacing: 4

        Repeater {
            model: SystemTray.items

            Item {
                id: delegate
                required property var modelData
                property var  sni:         modelData
                property bool killVisible: false

                width: 26; height: root.theme?.pillHeight ?? 24

                opacity: 0.0
                scale:   0.5
                Component.onCompleted: { opacity = 0; scale = 0.5; entryAnim.start() }

                SequentialAnimation {
                    id: entryAnim
                    ParallelAnimation {
                        NumberAnimation { target: delegate; property: "opacity"; to: 1; duration: 200; easing.type: Easing.OutQuad }
                        NumberAnimation { target: delegate; property: "scale";   to: 1; duration: 220; easing.type: Easing.OutBack }
                    }
                }

                Rectangle {
                    anchors.centerIn: parent
                    width: 22; height: 22
                    radius: root.theme.radius(root.barShape)
                    color: iconArea.containsMouse && !delegate.killVisible
                           ? root.theme.hoverAccent : "transparent"
                    Behavior on color  { ColorAnimation  { duration: root.theme.animFast } }
                    Behavior on radius { NumberAnimation { duration: root.theme.animSlow; easing.type: Easing.OutCubic } }
                }

                IconImage {
                    id: appIcon
                    anchors.centerIn: parent
                    implicitSize: 16
                    source:  delegate.sni?.icon ?? ""
                    visible: source !== ""
                }

                Rectangle {
                    anchors.centerIn: parent
                    width: 16; height: 16
                    visible: !appIcon.visible
                    radius:  root.theme.radius(root.barShape)
                    color:   root.theme.pw(root.theme.pal?.colors?.color9 || "#7dcfff", 0.28)
                    Behavior on radius { NumberAnimation { duration: root.theme.animSlow; easing.type: Easing.OutCubic } }
                }

                Rectangle {
                    visible: (delegate.sni?.status === 2) && !delegate.killVisible
                    width: 5; height: 5; radius: 3
                    color: root.theme.color1
                    anchors { bottom: parent.bottom; right: parent.right; margins: 1 }
                    SequentialAnimation on opacity {
                        running: delegate.sni?.status === 2
                        loops:   Animation.Infinite
                        NumberAnimation { to: 0.2; duration: 600; easing.type: Easing.InOutSine }
                        NumberAnimation { to: 1.0; duration: 600; easing.type: Easing.InOutSine }
                    }
                }

                Rectangle {
                    id: killBadge
                    width: 13; height: 13
                    radius: root.barShape ? 2 : 6
                    color:  killMa.containsMouse
                            ? root.theme.color1
                            : root.theme.pw(root.theme.pal?.colors?.color1 || "#f7768e", 0.82)
                    anchors { top: parent.top; right: parent.right; topMargin: -3; rightMargin: -3 }
                    z: 10
                    opacity: delegate.killVisible ? 1.0 : 0.0
                    scale:   delegate.killVisible ? 1.0 : 0.4
                    Behavior on opacity { NumberAnimation { duration: root.theme.animFast;   easing.type: Easing.OutCubic } }
                    Behavior on scale   { NumberAnimation { duration: root.theme.animNormal; easing.type: Easing.OutBack  } }
                    Behavior on color   { ColorAnimation  { duration: root.theme.animFast } }
                    Behavior on radius  { NumberAnimation { duration: root.theme.animSlow  } }

                    Text {
                        anchors.centerIn: parent
                        text: "✕"; color: root.theme.bg
                        font { family: root.theme.fontFamily; pixelSize: 7; weight: Font.Bold }
                    }

                    MouseArea {
                        id: killMa
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: {
                            delegate.killVisible = false
                            root.doKill(delegate.sni)
                        }
                    }
                }

                QsMenuAnchor {
                    id: nativeMenuAnchor
                    menu: delegate.sni?.menu ?? null
                    anchor.window: root.parentWindow
                    anchor.rect: Qt.rect(
                        delegate.mapToItem(root.parentWindow?.contentItem, 0, 0).x,
                        delegate.mapToItem(root.parentWindow?.contentItem, 0, 0).y + delegate.height + 4,
                        delegate.width, 0)
                }

                MouseArea {
                    id: iconArea
                    anchors.fill: parent
                    hoverEnabled: true
                    acceptedButtons: Qt.LeftButton | Qt.MiddleButton | Qt.RightButton
                    cursorShape: Qt.PointingHandCursor
                    onEntered: delegate.killVisible = true
                    onExited:  delegate.killVisible = false
                    onPressed:  delegate.scale = 0.82
                    onReleased: bounceAnim.restart()
                    SequentialAnimation {
                        id: bounceAnim
                        NumberAnimation { target: delegate; property: "scale"; to: 1.10; duration: 70;  easing.type: Easing.OutQuad   }
                        NumberAnimation { target: delegate; property: "scale"; to: 1.0;  duration: 110; easing.type: Easing.InOutQuad }
                    }
                    onClicked: function(mouse) {
                        if (mouse.button === Qt.MiddleButton) {
                            delegate.sni?.secondaryActivate()
                            return
                        }
                        if (mouse.button === Qt.RightButton) {
                            nativeMenuAnchor.open()
                            return
                        }
                        delegate.sni?.activate()
                    }
                }
            }
        }
    }
}
