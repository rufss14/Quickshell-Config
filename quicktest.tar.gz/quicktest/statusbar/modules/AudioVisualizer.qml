import QtQuick
import Quickshell.Io
import "../../theming" as T

// ── AudioVisualizer ───────────────────────────────────────────────────────────
// Standalone pill containing a live cava visualizer (16 bars, 60 fps).
// Falls back to a sine-wave demo animation when cava isn't running.
// Place as its own pill in StatusBarRoot's right area, before Clock's pill.
// ─────────────────────────────────────────────────────────────────────────────
Rectangle {
    id: root

    property bool barShape: false

    // ── Geometry ──────────────────────────────────────────────────────────────
    readonly property int barCount:   16
    readonly property int barW:       3
    readonly property int barGap:     3
    readonly property int hPad:       10
    readonly property int maxBarH:    implicitHeight - 6   // 3 px top + bottom

    implicitHeight: T.Theme.pillHeight
    implicitWidth:  barCount * (barW + barGap) - barGap + hPad * 2

    radius: T.Theme.radius(barShape)
    color:  T.Theme.pillBg

    Behavior on radius { NumberAnimation { duration: T.Theme.animSlow; easing.type: Easing.OutCubic } }

    // ── Live cava data ────────────────────────────────────────────────────────
    property var  bars:        []
    property bool hasLiveData: bars.length > 0

    Process {
        id: cavaProc
        command: [
            "bash", "-c",
            "cfg=$(mktemp /tmp/cava-qs-XXXXXX.ini)\n" +
            "printf '[general]\\nbars=16\\nframerate=60\\n[output]\\nmethod=raw\\ndata_format=ascii\\nascii_max_range=1000\\nraw_target=/dev/stdout\\nbar_delimiter=59\\nframe_delimiter=10\\nchannels=mono\\n' > \"$cfg\"\n" +
            "cava -p \"$cfg\"\n" +
            "rm -f \"$cfg\""
        ]
        stdout: SplitParser {
            splitMarker: "\n"
            onRead: function(line) {
                var t = line.trim()
                if (t.length === 0) return
                var parts = t.split(";")
                var arr = []
                for (var j = 0; j < parts.length; j++) {
                    var s = parts[j].trim()
                    if (s.length === 0) continue
                    var v = parseInt(s)
                    if (!isNaN(v)) arr.push(v / 1000.0)
                }
                if (arr.length >= 2) root.bars = arr
            }
        }
        running: true
    }

    // ── Sine-wave demo fallback (runs only when no live cava data) ────────────
    property var demoBars: []

    Timer {
        interval: 50
        running:  !root.hasLiveData
        repeat:   true
        onTriggered: {
            var now = Date.now() / 1000
            var arr = []
            for (var i = 0; i < root.barCount; i++) {
                var v = 0.5 + 0.45 * Math.sin(now * 2.1 + i * 0.7)
                           + 0.15 * Math.sin(now * 5.3 + i * 1.3)
                arr.push(Math.max(0.02, Math.min(1.0, v)))
            }
            root.demoBars = arr
        }
    }

    property var displayBars: hasLiveData ? bars : demoBars

    // ── Bar visualizer ────────────────────────────────────────────────────────
    Row {
        anchors.centerIn: parent
        spacing: root.barGap

        Repeater {
            model: root.displayBars.length

            // Outer column — full pill height, clips bar growth to bottom
            Item {
                width:  root.barW
                height: root.maxBarH

                property real barVal: index < root.displayBars.length
                                      ? root.displayBars[index] : 0

                // Actual bar — anchored to bottom, grows upward
                Rectangle {
                    anchors.bottom: parent.bottom
                    width:  parent.width
                    height: Math.max(2, Math.round(parent.barVal * parent.height))
                    radius: 0

                    gradient: Gradient {
                        GradientStop {
                            position: 0.0
                            color: T.Theme.pw(T.Theme.pal?.colors?.color4, 0.90)
                        }
                        GradientStop {
                            position: 1.0
                            color: T.Theme.pw(T.Theme.pal?.colors?.color4, 0.35)
                        }
                    }

                    Behavior on height {
                        NumberAnimation { duration: 60; easing.type: Easing.OutQuad }
                    }
                }
            }
        }
    }

}
