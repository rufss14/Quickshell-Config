import QtQuick
import Quickshell.Io
import "../../theming" as T
import "../../overlay/modules" as OV

// ── UpdateButton ──────────────────────────────────────────────────────────────
// Shows update count badge + pulsing dot while checking.
// Clicking opens the UpdatePanel popup and passes the current package count.
//
// Fix: guard _startCheck against re-entrant launches; count lines from
// checkupdates stdout directly so we don't lose the exit code through a pipe.
// Exit-code semantics for checkupdates:
//   0  → updates found  (stdout has one line per package)
//   2  → no updates     (stdout is empty)
//   1  → error/lock     (preserve last known count, mark hasError)
// ─────────────────────────────────────────────────────────────────────────────
Rectangle {
    id: root

    property bool barShape:    false
    property var  updatePanel: OV.Panels.updatePanel

    // Resolved handle — whichever is non-null first
    readonly property var _panel: updatePanel ?? OV.Panels.updatePanel

    // ── State ──────────────────────────────────────────────────────────────────
    QtObject {
        id: updateInfo
        property int  count:    0
        property bool checking: false
        property bool hasError: false   // true when last check returned code 1
    }

    // ── Check process ──────────────────────────────────────────────────────────
    // We read lines directly instead of piping through wc -l so that
    // the exit code lands in onExited() rather than wc's exit code.
    Process {
        id: checkProcess

        property int _lines: 0   // accumulator; reset each run

        command: ["checkupdates"]

        stdout: SplitParser {
            onRead: function(line) {
                if (line.trim().length > 0)
                    checkProcess._lines++
            }
        }

        onExited: function(code) {
            if (checkProcess._lines > 0) {
                // Packages were listed → count them
                updateInfo.count    = checkProcess._lines
                updateInfo.hasError = false
            } else if (code !== 1) {
                // code 0/2: clean run, no updates → reset count
                updateInfo.count    = 0
                updateInfo.hasError = false
            }
            // code 1: error / db lock → leave previous count, flag error
            else { updateInfo.hasError = true }

            checkProcess._lines  = 0
            updateInfo.checking  = false
        }
    }

    // ── Trigger logic ──────────────────────────────────────────────────────────
    function _startCheck() {
        // Guard: never start a second instance while one is running
        if (checkProcess.running) return
        checkProcess._lines = 0
        updateInfo.checking = true
        checkProcess.running = true
    }

    // Periodic check every 10 min; fire immediately on load
    Timer {
        interval: 600000; running: true; repeat: true; triggeredOnStart: true
        onTriggered: root._startCheck()
    }

    // Shorter re-check delay after an update finishes
    Timer {
        id: recheckTimer
        interval: 90000; repeat: false
        onTriggered: root._startCheck()
    }

    Connections {
        target: root._panel
        function onUpdateFinished() { recheckTimer.start() }
    }

    // ── Visuals ────────────────────────────────────────────────────────────────
    implicitWidth:  updateInfo.count > 0 ? 44 : 40
    implicitHeight: T.Theme.pillHeight
    radius: T.Theme.radius(barShape)
    color:  btn.containsMouse
        ? T.Theme.hoverFull
        : (updateInfo.count > 0
            ? T.Theme.pw(T.Theme.pal?.colors?.color1, 0.15)
            : T.Theme.pillBg)

    Behavior on implicitWidth { NumberAnimation { duration: T.Theme.animFast } }
    Behavior on color         { ColorAnimation  { duration: T.Theme.animFast } }
    Behavior on radius        { NumberAnimation { duration: T.Theme.animSlow; easing.type: Easing.OutCubic } }

    // Update icon — dims while checking
    Image {
        anchors.centerIn: parent
        source: "../../theming/icons/update.svg"
        width: 16; height: 16; fillMode: Image.PreserveAspectFit
        opacity: updateInfo.checking ? 0.4 : 1.0
        Behavior on opacity { NumberAnimation { duration: 300 } }
    }

    // ── Count badge ────────────────────────────────────────────────────────────
    Rectangle {
        visible: updateInfo.count > 0 && !updateInfo.checking
        width:   updateInfo.count > 99 ? 18
               : updateInfo.count >  9 ? 16 : 13
        height:  13
        radius:  barShape ? 2 : 6
        color:   updateInfo.hasError ? T.Theme.color3 : T.Theme.color1
        anchors { top: parent.top; right: parent.right; topMargin: -3; rightMargin: -3 }

        Behavior on width  { NumberAnimation { duration: T.Theme.animFast } }
        Behavior on radius { NumberAnimation { duration: T.Theme.animSlow } }
        Behavior on color  { ColorAnimation  { duration: T.Theme.animFast } }

        Text {
            anchors.centerIn: parent
            text:  updateInfo.count > 99 ? "99+" : updateInfo.count
            color: T.Theme.bg
            font { family: T.Theme.fontFamily; pixelSize: 8; weight: Font.Bold }
        }
    }

    // ── Checking dot — pulsing while a check is in flight ─────────────────────
    Rectangle {
        visible: updateInfo.checking
        width: 6; height: 6; radius: 3
        color: T.Theme.color9
        anchors { top: parent.top; right: parent.right; topMargin: -1; rightMargin: -1 }

        SequentialAnimation on opacity {
            running: updateInfo.checking; loops: Animation.Infinite
            NumberAnimation { to: 0.15; duration: 500 }
            NumberAnimation { to: 1.00; duration: 500 }
        }
    }

    // ── Click ──────────────────────────────────────────────────────────────────
    MouseArea {
        id: btn
        anchors.fill: parent
        hoverEnabled: true
        cursorShape:  Qt.PointingHandCursor
        onClicked: {
            if (root._panel)
                root._panel.startUpdate(updateInfo.count)
        }
    }
}
