import QtQuick
import QtQuick.Layouts
import Quickshell.Hyprland
import "../../theming" as T

// ── Workspaces ────────────────────────────────────────────────────────────────
// Center pill: 5 workspace dots, active dot expands.
//
// Dot states:
//   focused  → full accent color (color1), wide pill
//   occupied → medium accent glow (wsOccupied), narrow dot
//   empty    → very faint dot (wsEmpty), narrow dot
// ─────────────────────────────────────────────────────────────────────────────
Rectangle {
    id: root

    property bool barShape: false

    readonly property int currentWs:    Hyprland.focusedWorkspace?.id ?? 1
    readonly property int wsStart:      currentWs <= 5 ? 1 : 6

    implicitWidth:  120
    implicitHeight: T.Theme.pillHeight
    radius: T.Theme.radius(barShape)
    color:  T.Theme.pillBg

    Behavior on radius { NumberAnimation { duration: T.Theme.animSlow; easing.type: Easing.OutCubic } }

    RowLayout {
        anchors.centerIn: parent
        spacing: 8

        Repeater {
            model: 5
            delegate: Rectangle {
                id: dot

                readonly property int  wsId:     root.wsStart + index
                readonly property var  ws:       Hyprland.workspaces.values.find(w => w.id === wsId)
                readonly property bool isFocused: root.currentWs === wsId
                // ws being defined means the workspace exists and has at least one window
                readonly property bool isOccupied: ws !== undefined && !isFocused

                Layout.preferredWidth:  isFocused ? 26 : 10
                Layout.preferredHeight: 10
                radius: barShape ? 2 : 5

                color: isFocused   ? T.Theme.wsFocused
                     : isOccupied  ? T.Theme.wsFocused
                     :               T.Theme.wsEmpty

                Behavior on Layout.preferredWidth {
                    NumberAnimation {
                        duration: T.Theme.animNormal
                        easing.type: Easing.OutCubic
                    }
                }
                Behavior on color {
                    ColorAnimation { duration: T.Theme.animNormal }
                }
                Behavior on radius {
                    NumberAnimation { duration: T.Theme.animSlow }
                }

                MouseArea {
                    anchors.fill: parent
                    cursorShape:  Qt.PointingHandCursor
                    onClicked:    Hyprland.dispatch("workspace " + dot.wsId)
                }
            }
        }
    }
}
