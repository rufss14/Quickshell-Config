import QtQuick
import Quickshell
import Quickshell.Io
import "../../theming" as T

// ── BrightnessSlider ──────────────────────────────────────────────────────────
// iPhone-style fill bar with inner pill. No icons, no thumb.
// standalone: true  → draws its own outer pillBg (unified mode)
// standalone: false → transparent outer bg, inner pill acts as visual container
//                     (split mode, the PillRect provides the outer background)
// ─────────────────────────────────────────────────────────────────────────────
Rectangle {
    id: root

    property bool barShape:   false
    property bool standalone: true

    property int  brightness: 50
    property bool useDdc:     false
    property bool dragging:   false

    implicitWidth:  110
    implicitHeight: T.Theme.pillHeight

    // Outer bg: only drawn in standalone/unified mode.
    // In split mode the enclosing PillRect is the outer background.
    radius: standalone ? T.Theme.pillRadius : height / 2
    color:  standalone ? T.Theme.pillBg     : "transparent"

    Behavior on color  { ColorAnimation  { duration: T.Theme.animFast } }
    Behavior on radius { NumberAnimation { duration: T.Theme.animFast; easing.type: Easing.OutCubic } }

    // ── Persist brightness across reloads ─────────────────────────────────────
    PersistentProperties {
        id: persist
        reloadableId: "brightnessPersist"
        property int savedBrightness: 50
        onLoaded: root.brightness = persist.savedBrightness
    }
    // Keep saved value in sync whenever brightness changes
    onBrightnessChanged: persist.savedBrightness = brightness

    // ── Backend ───────────────────────────────────────────────────────────────
    Process {
        id: probeProc
        command: ["sh", "-c",
            "ddcutil getvcp 10 2>/dev/null | grep -oP 'current value =\\s*\\K[0-9]+'"]
        running: false
        stdout: StdioCollector { id: probeOut }
        onExited: function(code) {
            var v = parseInt(probeOut.text.trim())
            if (code === 0 && !isNaN(v)) {
                root.useDdc     = true
                root.brightness = Math.max(0, Math.min(100, v))
            } else {
                root.useDdc = false
                brightRead.running = true
            }
        }
    }

    Process {
        id: brightRead
        command: ["sh", "-c",
            "val=$(brightnessctl g); max=$(brightnessctl m); echo $((val * 100 / max))"]
        running: false
        stdout: StdioCollector { id: brightOut }
        onExited: function() {
            var v = parseInt(brightOut.text.trim())
            if (!isNaN(v)) root.brightness = Math.max(0, Math.min(100, v))
        }
    }

    Process { id: setProc; running: false }

    function applyBrightness(val) {
        val = Math.max(0, Math.min(100, val))
        setProc.command = root.useDdc
            ? ["ddcutil", "setvcp", "10", val.toString()]
            : ["brightnessctl", "set", val.toString() + "%"]
        setProc.running = true
    }

    Component.onCompleted: probeProc.running = true

    // ── Inner pill ────────────────────────────────────────────────────────────
    // In standalone mode: subtle translucent track sitting inside the outer pill.
    // In split mode: full pillBg pill — this IS the visual "pill" the user sees
    //                inside the enclosing PillRect, matching the wallpaper/barmode
    //                inner-pill pattern used elsewhere in split mode.
    Rectangle {
        id: innerPill
        anchors.fill:    parent
        anchors.margins: 4
        radius:          height / 2
        color:           root.standalone
                             ? Qt.rgba(1, 1, 1, 0.10)
                             : T.Theme.pillBg
        clip:            true

        Behavior on color  { ColorAnimation  { duration: T.Theme.animFast } }
        Behavior on radius { NumberAnimation { duration: T.Theme.animFast; easing.type: Easing.OutCubic } }

        // ── Fill bar ─────────────────────────────────────────────────────────
        Rectangle {
            anchors.top:    parent.top
            anchors.bottom: parent.bottom
            anchors.left:   parent.left
            width:  (root.brightness / 100) * parent.width
            radius: innerPill.radius
            color:  T.Theme.pw(T.Theme.pal?.colors?.color9 || "#7dcfff",
                               sliderMa.containsMouse || root.dragging ? 0.90 : 0.70)
            Behavior on width { NumberAnimation { duration: root.dragging ? 0 : T.Theme.animFast; easing.type: Easing.OutCubic } }
            Behavior on color { ColorAnimation  { duration: T.Theme.animFast } }
        }
    }

    // ── Input ─────────────────────────────────────────────────────────────────
    MouseArea {
        id: sliderMa
        anchors.fill:    parent
        hoverEnabled:    true
        cursorShape:     Qt.PointingHandCursor
        preventStealing: true

        // Map mouse X → 0–100, clamped to the inner pill's horizontal extent
        function posToValue(mouseX) {
            var lo      = innerPill.x
            var hi      = innerPill.x + innerPill.width
            var clamped = Math.max(lo, Math.min(hi, mouseX))
            return Math.round((clamped - lo) / innerPill.width * 100)
        }

        onPressed:         function(e) { root.dragging = true;  root.brightness = posToValue(e.x) }
        onReleased:        function()  { root.dragging = false; root.applyBrightness(root.brightness) }
        onPositionChanged: function(e) { if (pressed) root.brightness = posToValue(e.x) }
        onWheel: function(e) {
            var d = e.angleDelta.y > 0 ? 5 : -5
            root.brightness = Math.max(0, Math.min(100, root.brightness + d))
            root.applyBrightness(root.brightness)
        }
    }
}
