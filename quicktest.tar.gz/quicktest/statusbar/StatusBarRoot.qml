import Quickshell
import Quickshell.Wayland
import Quickshell.Hyprland
import Quickshell.Services.SystemTray
import QtQuick
import QtQuick.Layouts
import "../theming" as T
import "modules"
import "../overlay/modules" as OV

// ── StatusBarRoot ─────────────────────────────────────────────────────────────
// Single PanelWindow, full width, always present.
//
// barMode false → one unified bar:
//   [BarShape | BarMode]  [Wallpaper]   left (two separate pills)
//   [Update | Workspaces | Reload]      center
//   [Clock]                             right
//
// barMode true  → floating pill rects:
//   [BarShape | BarMode]  (left pill)
//   [Wallpaper]           (wallpaper pill, separate)
//   [Update | Workspaces | Reload]  (center pill)
//   [Clock]               (right pill)
//
// The wallpaper button ALWAYS lives in its own pill, never merged with bar controls.
// The wallpaper popup is a separate PanelWindow so it renders outside the bar bounds.
// ─────────────────────────────────────────────────────────────────────────────
PanelWindow {
    id: root
    Component.onCompleted: console.log("[StatusBarRoot] updatePanel=", updatePanel)

    PersistentProperties {
        id: persist
        reloadableId: "statusBarPersist"
        property bool barShape:      false
        property bool barMode:       false
        property bool wallpaperOpen: false
        property bool clockOpen:     false
        onLoaded: {
            root.barShape      = persist.barShape
            root.barMode       = persist.barMode
            root.wallpaperOpen = persist.wallpaperOpen
            root.clockOpen     = persist.clockOpen
        }
    }

    property bool barShape:      false
    property bool barMode:       false
    property bool wallpaperOpen: false
    property bool clockOpen:     false
    property var  updatePanel:   null

    onBarShapeChanged:      persist.barShape      = barShape
    onBarModeChanged:       persist.barMode       = barMode
    onWallpaperOpenChanged: persist.wallpaperOpen = wallpaperOpen
    onClockOpenChanged:     persist.clockOpen     = clockOpen

    anchors.top:   true
    anchors.left:  true
    anchors.right: true
    implicitHeight: T.Theme.barHeight
    color: "transparent"

    readonly property int splitMargin: root.barShape ? 0 : T.Theme.barMargin
    readonly property int splitRadius: root.barShape ? 0 : T.Theme.pillRadius

    // ─── Transition timing ────────────────────────────────────────
    readonly property int fadeOutDur: T.Theme.animNormal
    readonly property int fadeGap:    20
    readonly property int fadeInDur:  T.Theme.animNormal
    readonly property int shapeAnim:  T.Theme.animSlow

    // ═════════════════════════════════════════════════════════════
    // WALLPAPER POPUP — floating overlay, no exclusive zone,
    // flush below the bar, draggable by its header strip.
    // ═════════════════════════════════════════════════════════════
    PanelWindow {
        id: wallpaperPopupWindow

        screen: root.screen

        // No spanning anchors — explicit position so the compositor never
        // reserves space and open windows are not pushed aside.
        WlrLayershell.layer:         WlrLayer.Overlay
        WlrLayershell.namespace:     "quickshell-wallpaper-popup"
        WlrLayershell.exclusiveZone: -1   // Ignore — never displaces windows

        // Drag offset — starts flush below the left pill edge.
        property int dragOffsetX: root.splitMargin + 8
        property int dragOffsetY: T.Theme.barHeight + 2

        // Position via PanelWindow margins — the correct offset API for anchored edges.
        // anchors booleans select the edge; margins.top/left set the pixel offset from it.
        anchors.top:  true
        anchors.left: true
        margins.top:  dragOffsetY
        margins.left: dragOffsetX

        implicitWidth:  535
        implicitHeight: 340
        color: "transparent"
        visible: root.wallpaperOpen || popupCard.opacity > 0.005

        // Re-snap when bar shape margin changes
        Connections {
            target: root
            function onSplitMarginChanged() {
                wallpaperPopupWindow.dragOffsetX = root.splitMargin + 8
                wallpaperPopupWindow.dragOffsetY = T.Theme.barHeight + 2
            }
        }

        Rectangle {
            id: popupCard
            anchors.fill: parent

            radius: T.Theme.pillRadius + 4
            color:        T.Theme.bg
            border.color: T.Theme.barBorder
            border.width: 1

            opacity: root.wallpaperOpen ? 1.0 : 0.0
            scale:   root.wallpaperOpen ? 1.0 : 0.96
            transformOrigin: Item.Top

            Behavior on opacity { NumberAnimation { duration: T.Theme.animNormal; easing.type: Easing.OutCubic } }
            Behavior on scale   { NumberAnimation { duration: T.Theme.animNormal; easing.type: Easing.OutBack  } }

            // ── Drag handle — the header strip (42 px, same as WallpaperPanel header) ──
            MouseArea {
                id: dragHandle
                anchors.top:   parent.top
                anchors.left:  parent.left
                anchors.right: parent.right
                height: 42
                z: 10
                cursorShape: pressed ? Qt.ClosedHandCursor : Qt.OpenHandCursor
                hoverEnabled: true
                propagateComposedEvents: true

                property int _pressGx: 0
                property int _pressGy: 0
                property int _startX:  0
                property int _startY:  0

                onPressed: function(mouse) {
                    _pressGx = mouse.x + wallpaperPopupWindow.dragOffsetX
                    _pressGy = mouse.y + wallpaperPopupWindow.dragOffsetY
                    _startX  = wallpaperPopupWindow.dragOffsetX
                    _startY  = wallpaperPopupWindow.dragOffsetY
                }
                onPositionChanged: function(mouse) {
                    if (!pressed) return
                    var gx = mouse.x + wallpaperPopupWindow.dragOffsetX
                    var gy = mouse.y + wallpaperPopupWindow.dragOffsetY
                    wallpaperPopupWindow.dragOffsetX = _startX + (gx - _pressGx)
                    wallpaperPopupWindow.dragOffsetY = _startY + (gy - _pressGy)
                }
                onClicked: mouse => { mouse.accepted = false }
            }

            OV.WallpaperPanel {
                anchors.fill: parent
            }
        }
    }

    // ═════════════════════════════════════════════════════════════
    // CLOCK POPUP
    // ═════════════════════════════════════════════════════════════
    PanelWindow {
        id: clockPopupWindow

        screen: root.screen

        WlrLayershell.layer:         WlrLayer.Overlay
        WlrLayershell.namespace:     "quickshell-clock-popup"
        WlrLayershell.exclusiveZone: -1

        property int dragOffsetX: root.splitMargin + 8
        property int dragOffsetY: T.Theme.barHeight + 2

        anchors.top:   true
        anchors.right: true
        margins.top:   dragOffsetY
        margins.right: dragOffsetX

        implicitWidth:  320
        implicitHeight: 400
        color: "transparent"
        visible: root.clockOpen || clockCard.opacity > 0.005

        Connections {
            target: root
            function onSplitMarginChanged() {
                clockPopupWindow.dragOffsetX = root.splitMargin + 8
                clockPopupWindow.dragOffsetY = T.Theme.barHeight + 2
            }
        }

        Rectangle {
            id: clockCard
            anchors.fill: parent

            radius: T.Theme.pillRadius + 4
            color:        T.Theme.bg
            border.color: T.Theme.barBorder
            border.width: 1

            opacity: root.clockOpen ? 1.0 : 0.0
            scale:   root.clockOpen ? 1.0 : 0.96
            transformOrigin: Item.TopRight

            Behavior on opacity { NumberAnimation { duration: T.Theme.animNormal; easing.type: Easing.OutCubic } }
            Behavior on scale   { NumberAnimation { duration: T.Theme.animNormal; easing.type: Easing.OutBack  } }

            // ── Drag handle ──────────────────────────────────────────────
            MouseArea {
                id: clockDragHandle
                anchors.top:   parent.top
                anchors.left:  parent.left
                anchors.right: parent.right
                height: 42
                z: 10
                cursorShape: pressed ? Qt.ClosedHandCursor : Qt.OpenHandCursor
                hoverEnabled: true
                propagateComposedEvents: true

                property int _pressGx: 0
                property int _pressGy: 0
                property int _startX:  0
                property int _startY:  0

                onPressed: function(mouse) {
                    _pressGx = mouse.x + clockPopupWindow.dragOffsetX
                    _pressGy = mouse.y + clockPopupWindow.dragOffsetY
                    _startX  = clockPopupWindow.dragOffsetX
                    _startY  = clockPopupWindow.dragOffsetY
                }
                onPositionChanged: function(mouse) {
                    if (!pressed) return
                    var gx = mouse.x + clockPopupWindow.dragOffsetX
                    var gy = mouse.y + clockPopupWindow.dragOffsetY
                    clockPopupWindow.dragOffsetX = _startX + (gx - _pressGx)
                    clockPopupWindow.dragOffsetY = _startY + (gy - _pressGy)
                }
                onClicked: mouse => { mouse.accepted = false }
            }
        }
    }

    // ═════════════════════════════════════════════════════════════
    // UNIFIED MODE
    // ═════════════════════════════════════════════════════════════
    PillRect {
        anchors.fill:    parent
        anchors.margins: root.splitMargin
        radius:          root.splitRadius
        border.color:    T.Theme.barBorder

        visible: unifiedInner.opacity > 0.005 || !root.barMode

        Behavior on anchors.margins { NumberAnimation { duration: root.shapeAnim; easing.type: Easing.OutCubic } }
        Behavior on radius          { NumberAnimation { duration: root.shapeAnim; easing.type: Easing.OutCubic } }
        Behavior on border.color    { ColorAnimation  { duration: T.Theme.animFast } }

        Item {
            id: unifiedInner
            anchors.fill: parent
            opacity: 1.0
            y: 0

            SequentialAnimation {
                id: unifiedOut
                running: false
                NumberAnimation { target: unifiedInner; property: "opacity"; to: 0.0; duration: root.fadeOutDur; easing.type: Easing.InCubic }
            }
            SequentialAnimation {
                id: unifiedIn
                running: false
                PauseAnimation  { duration: root.fadeOutDur + root.fadeGap }
                NumberAnimation { target: unifiedInner; property: "opacity"; to: 1.0; duration: root.fadeInDur; easing.type: Easing.OutCubic }
            }
            ParallelAnimation {
                id: unifiedSlideOut
                running: false
                NumberAnimation { target: unifiedInner; property: "y"; to: -5; duration: root.fadeOutDur; easing.type: Easing.InCubic }
            }
            ParallelAnimation {
                id: unifiedSlideIn
                running: false
                NumberAnimation { target: unifiedInner; property: "y"; to: 0; duration: root.fadeInDur; easing.type: Easing.OutCubic }
            }

            // ── Left ─────────────────────────────────────────────
            RowLayout {
                anchors.left:           parent.left
                anchors.verticalCenter: parent.verticalCenter
                anchors.leftMargin:     12
                spacing: 6

                // ── BarShape + BarMode pill ──
                Rectangle {
                    id: uLeftPill
                    implicitHeight: T.Theme.pillHeight
                    implicitWidth:  80
                    radius: T.Theme.radius(root.barShape)
                    color:  T.Theme.pillBg
                    Behavior on color  { ColorAnimation  { duration: T.Theme.animFast } }
                    Behavior on radius { NumberAnimation { duration: root.shapeAnim; easing.type: Easing.OutCubic } }

                    RowLayout {
                        anchors.centerIn: parent
                        spacing: 0

                        // BarShape button
                        Rectangle {
                            implicitWidth:  40
                            implicitHeight: T.Theme.pillHeight
                            radius: uLeftPill.radius
                            color: uShapeMa.containsMouse ? T.Theme.hoverFull : "transparent"
                            Behavior on color { ColorAnimation { duration: T.Theme.animFast } }
                            Image {
                                anchors.centerIn: parent
                                source: root.barShape ? "../theming/icons/winoff.svg" : "../theming/icons/winon.svg"
                                width: 16; height: 16; fillMode: Image.PreserveAspectFit
                            }
                            MouseArea {
                                id: uShapeMa; anchors.fill: parent
                                hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                                onClicked: root.barShape = !root.barShape
                            }
                        }

                        // Divider
                        Rectangle { width: 1; height: 14; color: T.Theme.dimFg; Layout.alignment: Qt.AlignVCenter }

                        // BarMode button
                        Rectangle {
                            implicitWidth:  40
                            implicitHeight: T.Theme.pillHeight
                            radius: uLeftPill.radius
                            color: uModeMa.containsMouse ? T.Theme.hoverFull : "transparent"
                            Behavior on color { ColorAnimation { duration: T.Theme.animFast } }
                            Image {
                                anchors.centerIn: parent
                                source: "../theming/icons/barmode.svg"
                                width: 16; height: 16; fillMode: Image.PreserveAspectFit
                            }
                            MouseArea {
                                id: uModeMa; anchors.fill: parent
                                hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                                onClicked: root.barMode = !root.barMode
                            }
                        }
                    }
                }

                // ── Wallpaper pill — separate from bar controls ──
                Rectangle {
                    implicitHeight: T.Theme.pillHeight
                    implicitWidth:  40
                    radius: T.Theme.radius(root.barShape)
                    color: uWallMa.containsMouse
                        ? (root.wallpaperOpen
                            ? T.Theme.pw(T.Theme.pal?.colors?.color9, 0.30)
                            : T.Theme.hoverFull)
                        : (root.wallpaperOpen
                            ? T.Theme.pw(T.Theme.pal?.colors?.color9, 0.18)
                            : T.Theme.pillBg)
                    Behavior on color  { ColorAnimation  { duration: T.Theme.animFast } }
                    Behavior on radius { NumberAnimation { duration: root.shapeAnim; easing.type: Easing.OutCubic } }

                    Image {
                        anchors.centerIn: parent
                        source: "../theming/icons/wallpaper.svg"
                        width: 16; height: 16; fillMode: Image.PreserveAspectFit
                    }
                    MouseArea {
                        id: uWallMa; anchors.fill: parent
                        hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                        onClicked: root.wallpaperOpen = !root.wallpaperOpen
                    }
                }

                // ── Brightness pill ──
                BrightnessSlider { barShape: root.barShape }
            }

            // ── Center ───────────────────────────────────────────
            RowLayout {
                id: centerRow
                anchors.centerIn: parent
                spacing: 10

                UpdateButton { barShape: root.barShape; updatePanel: root.updatePanel }
                Workspaces   { barShape: root.barShape }
                ReloadButton { barShape: root.barShape }
            }

            // ── Tray — floats right of reload, workspaces stay centered ──
            Tray {
                anchors.left:           centerRow.right
                anchors.verticalCenter: parent.verticalCenter
                anchors.leftMargin:     6
                barShape:     root.barShape
                parentWindow: root
                visible:      itemCount > 0
            }

            // ── Right ────────────────────────────────────────────
            RowLayout {
                anchors.right:          parent.right
                anchors.verticalCenter: parent.verticalCenter
                anchors.rightMargin:    12
                spacing: 8

                AudioVisualizer { barShape: root.barShape }
                Clock { barShape: root.barShape; clockOpen: root.clockOpen; onToggleClock: root.clockOpen = !root.clockOpen }
            }
        }
    }

    // ═════════════════════════════════════════════════════════════
    // SPLIT MODE
    // ═════════════════════════════════════════════════════════════

    // ── Split left — BarShape + BarMode only ─────────────────────
    PillRect {
        id: splitLeftPill
        anchors.top:    parent.top
        anchors.bottom: parent.bottom
        anchors.left:   parent.left

        anchors.topMargin:    root.splitMargin
        anchors.bottomMargin: root.splitMargin
        anchors.leftMargin:   root.splitMargin

        radius:        root.splitRadius
        border.color:  T.Theme.barBorder
        visible:       splitLeftInner.opacity > 0.005 || root.barMode
        implicitWidth: 96

        Behavior on anchors.topMargin    { NumberAnimation { duration: root.shapeAnim; easing.type: Easing.OutCubic } }
        Behavior on anchors.bottomMargin { NumberAnimation { duration: root.shapeAnim; easing.type: Easing.OutCubic } }
        Behavior on anchors.leftMargin   { NumberAnimation { duration: root.shapeAnim; easing.type: Easing.OutCubic } }
        Behavior on radius               { NumberAnimation { duration: root.shapeAnim; easing.type: Easing.OutCubic } }
        Behavior on border.color         { ColorAnimation  { duration: T.Theme.animFast } }

        Item {
            id: splitLeftInner
            anchors.fill: parent
            opacity: 0.0
            y: 5

            SequentialAnimation {
                id: splitLeftIn
                running: false
                PauseAnimation { duration: root.fadeOutDur + root.fadeGap }
                ParallelAnimation {
                    NumberAnimation { target: splitLeftInner; property: "opacity"; to: 1.0; duration: root.fadeInDur; easing.type: Easing.OutCubic }
                    NumberAnimation { target: splitLeftInner; property: "y";       to: 0;   duration: root.fadeInDur; easing.type: Easing.OutCubic }
                }
            }
            SequentialAnimation {
                id: splitLeftOut
                running: false
                ParallelAnimation {
                    NumberAnimation { target: splitLeftInner; property: "opacity"; to: 0.0; duration: root.fadeOutDur; easing.type: Easing.InCubic }
                    NumberAnimation { target: splitLeftInner; property: "y";       to: 5;   duration: root.fadeOutDur; easing.type: Easing.InCubic }
                }
            }

            // Inner merged pill — pillBg base holding both buttons
            Rectangle {
                anchors.centerIn: parent
                implicitWidth:  80
                implicitHeight: T.Theme.pillHeight
                radius: T.Theme.radius(root.barShape)
                color:  T.Theme.pillBg
                Behavior on color  { ColorAnimation  { duration: T.Theme.animFast } }
                Behavior on radius { NumberAnimation { duration: root.shapeAnim; easing.type: Easing.OutCubic } }

                RowLayout {
                    anchors.fill: parent
                    spacing: 0

                    // BarShape button
                    Rectangle {
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        radius: parent.parent.radius
                        color: sShapeMa.containsMouse ? T.Theme.hoverFull : "transparent"
                        Behavior on color { ColorAnimation { duration: T.Theme.animFast } }
                        Image {
                            anchors.centerIn: parent
                            source: root.barShape ? "../theming/icons/winoff.svg" : "../theming/icons/winon.svg"
                            width: 16; height: 16; fillMode: Image.PreserveAspectFit
                        }
                        MouseArea {
                            id: sShapeMa; anchors.fill: parent
                            hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                            onClicked: root.barShape = !root.barShape
                        }
                    }

                    // Divider
                    Rectangle { width: 1; height: 14; color: T.Theme.dimFg; Layout.alignment: Qt.AlignVCenter }

                    // BarMode button
                    Rectangle {
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        radius: parent.parent.radius
                        color: sModeMa.containsMouse ? T.Theme.hoverFull : "transparent"
                        Behavior on color { ColorAnimation { duration: T.Theme.animFast } }
                        Image {
                            anchors.centerIn: parent
                            source: "../theming/icons/barmode.svg"
                            width: 16; height: 16; fillMode: Image.PreserveAspectFit
                        }
                        MouseArea {
                            id: sModeMa; anchors.fill: parent
                            hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                            onClicked: root.barMode = !root.barMode
                        }
                    }
                }
            }
        }
    }

    // ── Split wallpaper pill — its own separate pill ──────────────
    PillRect {
        id: splitWallpaperPill
        anchors.top:    parent.top
        anchors.bottom: parent.bottom
        anchors.left:   splitLeftPill.right

        anchors.topMargin:    root.splitMargin
        anchors.bottomMargin: root.splitMargin
        anchors.leftMargin:   root.splitMargin

        radius:        root.splitRadius
        border.color:  T.Theme.barBorder
        implicitWidth: 56
        visible:       splitWallpaperInner.opacity > 0.005 || root.barMode

        Behavior on anchors.topMargin    { NumberAnimation { duration: root.shapeAnim; easing.type: Easing.OutCubic } }
        Behavior on anchors.bottomMargin { NumberAnimation { duration: root.shapeAnim; easing.type: Easing.OutCubic } }
        Behavior on anchors.leftMargin   { NumberAnimation { duration: root.shapeAnim; easing.type: Easing.OutCubic } }
        Behavior on radius               { NumberAnimation { duration: root.shapeAnim; easing.type: Easing.OutCubic } }
        Behavior on border.color         { ColorAnimation  { duration: T.Theme.animFast } }

        Item {
            id: splitWallpaperInner
            anchors.fill: parent
            opacity: 0.0
            y: 5

            SequentialAnimation {
                id: splitWallpaperIn
                running: false
                PauseAnimation { duration: root.fadeOutDur + root.fadeGap }
                ParallelAnimation {
                    NumberAnimation { target: splitWallpaperInner; property: "opacity"; to: 1.0; duration: root.fadeInDur; easing.type: Easing.OutCubic }
                    NumberAnimation { target: splitWallpaperInner; property: "y";       to: 0;   duration: root.fadeInDur; easing.type: Easing.OutCubic }
                }
            }
            SequentialAnimation {
                id: splitWallpaperOut
                running: false
                ParallelAnimation {
                    NumberAnimation { target: splitWallpaperInner; property: "opacity"; to: 0.0; duration: root.fadeOutDur; easing.type: Easing.InCubic }
                    NumberAnimation { target: splitWallpaperInner; property: "y";       to: 5;   duration: root.fadeOutDur; easing.type: Easing.InCubic }
                }
            }

            // Inner pill — same pillBg rect that UpdateButton/ReloadButton/BarMode use
            Rectangle {
                anchors.centerIn: parent
                implicitWidth:  40
                implicitHeight: T.Theme.pillHeight
                radius: T.Theme.radius(root.barShape)
                color: sWallMa.containsMouse
                    ? (root.wallpaperOpen
                        ? T.Theme.pw(T.Theme.pal?.colors?.color9, 0.30)
                        : T.Theme.hoverFull)
                    : (root.wallpaperOpen
                        ? T.Theme.pw(T.Theme.pal?.colors?.color9, 0.18)
                        : T.Theme.pillBg)
                Behavior on color  { ColorAnimation  { duration: T.Theme.animFast } }
                Behavior on radius { NumberAnimation { duration: T.Theme.animSlow; easing.type: Easing.OutCubic } }

                Image {
                    anchors.centerIn: parent
                    source: "../theming/icons/wallpaper.svg"
                    width: 16; height: 16; fillMode: Image.PreserveAspectFit
                }
                MouseArea {
                    id: sWallMa; anchors.fill: parent
                    hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                    onClicked: root.wallpaperOpen = !root.wallpaperOpen
                }
            }
        }
    }

    // ── Split brightness pill — sits right of wallpaper pill ─────
    PillRect {
        id: splitBrightnessPill
        anchors.top:    parent.top
        anchors.bottom: parent.bottom
        anchors.left:   splitWallpaperPill.right

        anchors.topMargin:    root.splitMargin
        anchors.bottomMargin: root.splitMargin
        anchors.leftMargin:   root.splitMargin

        radius:        root.splitRadius
        border.color:  T.Theme.barBorder
        implicitWidth: 110
        visible:       splitBrightnessInner.opacity > 0.005 || root.barMode

        Behavior on anchors.topMargin    { NumberAnimation { duration: root.shapeAnim; easing.type: Easing.OutCubic } }
        Behavior on anchors.bottomMargin { NumberAnimation { duration: root.shapeAnim; easing.type: Easing.OutCubic } }
        Behavior on anchors.leftMargin   { NumberAnimation { duration: root.shapeAnim; easing.type: Easing.OutCubic } }
        Behavior on radius               { NumberAnimation { duration: root.shapeAnim; easing.type: Easing.OutCubic } }
        Behavior on border.color         { ColorAnimation  { duration: T.Theme.animFast } }

        Item {
            id: splitBrightnessInner
            anchors.fill: parent
            opacity: 0.0
            y: 5

            SequentialAnimation {
                id: splitBrightnessIn
                running: false
                PauseAnimation { duration: root.fadeOutDur + root.fadeGap }
                ParallelAnimation {
                    NumberAnimation { target: splitBrightnessInner; property: "opacity"; to: 1.0; duration: root.fadeInDur; easing.type: Easing.OutCubic }
                    NumberAnimation { target: splitBrightnessInner; property: "y";       to: 0;   duration: root.fadeInDur; easing.type: Easing.OutCubic }
                }
            }
            SequentialAnimation {
                id: splitBrightnessOut
                running: false
                ParallelAnimation {
                    NumberAnimation { target: splitBrightnessInner; property: "opacity"; to: 0.0; duration: root.fadeOutDur; easing.type: Easing.InCubic }
                    NumberAnimation { target: splitBrightnessInner; property: "y";       to: 5;   duration: root.fadeOutDur; easing.type: Easing.InCubic }
                }
            }

            BrightnessSlider {
                anchors.centerIn: parent
                width:            parent.width - 8
                standalone:       false
                barShape:         root.barShape
            }
        }
    }

    // ── Split center ──────────────────────────────────────────────
    PillRect {
        id: splitCenterPill
        anchors.top:              parent.top
        anchors.bottom:           parent.bottom
        anchors.horizontalCenter: parent.horizontalCenter

        anchors.topMargin:    root.splitMargin
        anchors.bottomMargin: root.splitMargin

        radius:        root.splitRadius
        border.color:  T.Theme.barBorder
        visible:       splitCenterInner.opacity > 0.005 || root.barMode
        implicitWidth: centerBtns.implicitWidth + 24

        Behavior on anchors.topMargin    { NumberAnimation { duration: root.shapeAnim; easing.type: Easing.OutCubic } }
        Behavior on anchors.bottomMargin { NumberAnimation { duration: root.shapeAnim; easing.type: Easing.OutCubic } }
        Behavior on radius               { NumberAnimation { duration: root.shapeAnim; easing.type: Easing.OutCubic } }
        Behavior on border.color         { ColorAnimation  { duration: T.Theme.animFast } }

        Item {
            id: splitCenterInner
            anchors.fill: parent
            opacity: 0.0
            y: 5

            SequentialAnimation {
                id: splitCenterIn
                running: false
                PauseAnimation { duration: root.fadeOutDur + root.fadeGap }
                ParallelAnimation {
                    NumberAnimation { target: splitCenterInner; property: "opacity"; to: 1.0; duration: root.fadeInDur; easing.type: Easing.OutCubic }
                    NumberAnimation { target: splitCenterInner; property: "y";       to: 0;   duration: root.fadeInDur; easing.type: Easing.OutCubic }
                }
            }
            SequentialAnimation {
                id: splitCenterOut
                running: false
                ParallelAnimation {
                    NumberAnimation { target: splitCenterInner; property: "opacity"; to: 0.0; duration: root.fadeOutDur; easing.type: Easing.InCubic }
                    NumberAnimation { target: splitCenterInner; property: "y";       to: 5;   duration: root.fadeOutDur; easing.type: Easing.InCubic }
                }
            }

            RowLayout {
                id: centerBtns
                anchors.centerIn: parent
                spacing: 10

                UpdateButton { barShape: root.barShape; updatePanel: root.updatePanel }
                Workspaces   { barShape: root.barShape }
                ReloadButton { barShape: root.barShape }
            }
        }
    }

    // ── Split tray — own pill, immediately right of center ───────
    PillRect {
        id: splitTrayPill
        anchors.top:    parent.top
        anchors.bottom: parent.bottom
        anchors.left:   splitCenterPill.right

        anchors.topMargin:    root.splitMargin
        anchors.bottomMargin: root.splitMargin
        anchors.leftMargin:   root.splitMargin

        radius:        root.splitRadius
        border.color:  T.Theme.barBorder
        visible:       (splitTrayInner.opacity > 0.005 || root.barMode) && SystemTray.items.values.length > 0
        implicitWidth: SystemTray.items.values.length * 26 + Math.max(0, SystemTray.items.values.length - 1) * 4 + 32

        Behavior on anchors.topMargin    { NumberAnimation { duration: root.shapeAnim; easing.type: Easing.OutCubic } }
        Behavior on anchors.bottomMargin { NumberAnimation { duration: root.shapeAnim; easing.type: Easing.OutCubic } }
        Behavior on anchors.leftMargin   { NumberAnimation { duration: root.shapeAnim; easing.type: Easing.OutCubic } }
        Behavior on radius               { NumberAnimation { duration: root.shapeAnim; easing.type: Easing.OutCubic } }
        Behavior on border.color         { ColorAnimation  { duration: T.Theme.animFast } }

        Item {
            id: splitTrayInner
            anchors.fill: parent
            opacity: 0.0
            y: 5

            SequentialAnimation {
                id: splitTrayIn
                running: false
                PauseAnimation { duration: root.fadeOutDur + root.fadeGap }
                ParallelAnimation {
                    NumberAnimation { target: splitTrayInner; property: "opacity"; to: 1.0; duration: root.fadeInDur; easing.type: Easing.OutCubic }
                    NumberAnimation { target: splitTrayInner; property: "y";       to: 0;   duration: root.fadeInDur; easing.type: Easing.OutCubic }
                }
            }
            SequentialAnimation {
                id: splitTrayOut
                running: false
                ParallelAnimation {
                    NumberAnimation { target: splitTrayInner; property: "opacity"; to: 0.0; duration: root.fadeOutDur; easing.type: Easing.InCubic }
                    NumberAnimation { target: splitTrayInner; property: "y";       to: 5;   duration: root.fadeOutDur; easing.type: Easing.InCubic }
                }
            }

            Tray {
                id: trayComp
                anchors.centerIn: parent
                barShape:     root.barShape
                parentWindow: root
            }
        }
    }

    // ── Split visualizer (audio, sits left of clock pill) ─────────
    PillRect {
        id: splitVizPill
        anchors.top:    parent.top
        anchors.bottom: parent.bottom
        anchors.right:  splitRightPill.left

        anchors.topMargin:    root.splitMargin
        anchors.bottomMargin: root.splitMargin
        anchors.rightMargin:  root.splitMargin

        radius:        root.splitRadius
        border.color:  T.Theme.barBorder
        visible:       splitVizInner.opacity > 0.005 || root.barMode
        implicitWidth: vizComp.implicitWidth + 24

        Behavior on anchors.topMargin    { NumberAnimation { duration: root.shapeAnim; easing.type: Easing.OutCubic } }
        Behavior on anchors.bottomMargin { NumberAnimation { duration: root.shapeAnim; easing.type: Easing.OutCubic } }
        Behavior on anchors.rightMargin  { NumberAnimation { duration: root.shapeAnim; easing.type: Easing.OutCubic } }
        Behavior on radius               { NumberAnimation { duration: root.shapeAnim; easing.type: Easing.OutCubic } }
        Behavior on border.color         { ColorAnimation  { duration: T.Theme.animFast } }

        Item {
            id: splitVizInner
            anchors.fill: parent
            opacity: 0.0
            y: 5

            SequentialAnimation {
                id: splitVizIn
                running: false
                PauseAnimation { duration: root.fadeOutDur + root.fadeGap }
                ParallelAnimation {
                    NumberAnimation { target: splitVizInner; property: "opacity"; to: 1.0; duration: root.fadeInDur; easing.type: Easing.OutCubic }
                    NumberAnimation { target: splitVizInner; property: "y";       to: 0;   duration: root.fadeInDur; easing.type: Easing.OutCubic }
                }
            }
            SequentialAnimation {
                id: splitVizOut
                running: false
                ParallelAnimation {
                    NumberAnimation { target: splitVizInner; property: "opacity"; to: 0.0; duration: root.fadeOutDur; easing.type: Easing.InCubic }
                    NumberAnimation { target: splitVizInner; property: "y";       to: 5;   duration: root.fadeOutDur; easing.type: Easing.InCubic }
                }
            }

            AudioVisualizer {
                id: vizComp
                anchors.centerIn: parent
                barShape: root.barShape
            }
        }
    }

    // ── Split right ───────────────────────────────────────────────
    PillRect {
        id: splitRightPill
        anchors.top:    parent.top
        anchors.bottom: parent.bottom
        anchors.right:  parent.right

        anchors.topMargin:    root.splitMargin
        anchors.bottomMargin: root.splitMargin
        anchors.rightMargin:  root.splitMargin

        radius:        root.splitRadius
        border.color:  T.Theme.barBorder
        visible:       splitRightInner.opacity > 0.005 || root.barMode
        implicitWidth: rightBtns.implicitWidth + 24

        Behavior on anchors.topMargin    { NumberAnimation { duration: root.shapeAnim; easing.type: Easing.OutCubic } }
        Behavior on anchors.bottomMargin { NumberAnimation { duration: root.shapeAnim; easing.type: Easing.OutCubic } }
        Behavior on anchors.rightMargin  { NumberAnimation { duration: root.shapeAnim; easing.type: Easing.OutCubic } }
        Behavior on radius               { NumberAnimation { duration: root.shapeAnim; easing.type: Easing.OutCubic } }
        Behavior on border.color         { ColorAnimation  { duration: T.Theme.animFast } }

        Item {
            id: splitRightInner
            anchors.fill: parent
            opacity: 0.0
            y: 5

            SequentialAnimation {
                id: splitRightIn
                running: false
                PauseAnimation { duration: root.fadeOutDur + root.fadeGap }
                ParallelAnimation {
                    NumberAnimation { target: splitRightInner; property: "opacity"; to: 1.0; duration: root.fadeInDur; easing.type: Easing.OutCubic }
                    NumberAnimation { target: splitRightInner; property: "y";       to: 0;   duration: root.fadeInDur; easing.type: Easing.OutCubic }
                }
            }
            SequentialAnimation {
                id: splitRightOut
                running: false
                ParallelAnimation {
                    NumberAnimation { target: splitRightInner; property: "opacity"; to: 0.0; duration: root.fadeOutDur; easing.type: Easing.InCubic }
                    NumberAnimation { target: splitRightInner; property: "y";       to: 5;   duration: root.fadeOutDur; easing.type: Easing.InCubic }
                }
            }

            RowLayout {
                id: rightBtns
                anchors.centerIn: parent
                spacing: 8

                Clock { barShape: root.barShape; clockOpen: root.clockOpen; onToggleClock: root.clockOpen = !root.clockOpen }
            }
        }
    }

    // ═════════════════════════════════════════════════════════════
    // TRANSITION ORCHESTRATOR
    // ═════════════════════════════════════════════════════════════
    Connections {
        target: root
        function onBarModeChanged() {
            if (root.barMode) {
                unifiedOut.restart()
                unifiedSlideOut.restart()
                splitWallpaperIn.restart()
                splitBrightnessIn.restart()
                splitLeftIn.restart()
                splitCenterIn.restart()
                splitTrayIn.restart()
                splitVizIn.restart()
                splitRightIn.restart()
            } else {
                splitWallpaperOut.restart()
                splitBrightnessOut.restart()
                splitLeftOut.restart()
                splitCenterOut.restart()
                splitTrayOut.restart()
                splitVizOut.restart()
                splitRightOut.restart()
                unifiedIn.restart()
                unifiedSlideIn.restart()
            }
        }
    }
}
