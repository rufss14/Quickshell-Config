pragma Singleton
import QtQuick

// ── Panels ────────────────────────────────────────────────────────────────────
// Global singleton that holds references to overlay panel windows.
// UpdatePanel sets itself here on creation; any component can read from here.
// ─────────────────────────────────────────────────────────────────────────────
QtObject {
    property var updatePanel: null
}
