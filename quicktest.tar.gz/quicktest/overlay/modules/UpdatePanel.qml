import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Wayland
import Quickshell.Io
import "../../theming" as T
import "." as OM

PanelWindow {
    id: panel

    // Register into the Panels singleton so UpdateButton can find us
    // whether it uses the singleton path or the property-forwarding path.
    QtObject {
        Component.onCompleted: {
            OM.Panels.updatePanel = panel
            console.log("[UpdatePanel] registered into Panels.updatePanel")
        }
    }

    signal updateFinished()

    function startUpdate() {
        panel.visible    = true
        state.showPrompt = true
        state.running    = false
        state.done       = false
        state.hadError   = false
        state.progress   = 0.0
        state.statusText = ""
        Qt.callLater(() => passField.forceActiveFocus())
    }

    QtObject {
        id: state
        property bool   showPrompt: true
        property bool   running:    false
        property bool   done:       false
        property bool   hadError:   false
        property string sudoPass:   ""
        property real   progress:   0.0
        property string statusText: ""
    }

    // ── Full-screen overlay — does not push any windows ───────────────────────
    WlrLayershell.layer:     WlrLayer.Overlay
    WlrLayershell.namespace: "quickshell-update-panel"
    WlrLayershell.keyboardFocus: (state.showPrompt && visible)
                                    ? WlrKeyboardFocus.OnDemand
                                    : WlrKeyboardFocus.None

    anchors.top:    true
    anchors.left:   true
    anchors.right:  true
    anchors.bottom: true

    visible: false
    color:   "transparent"

    // Dismiss on click outside the pill
    MouseArea {
        anchors.fill: parent
        onClicked:    panel.visible = false
        propagateComposedEvents: true
    }

    // ── Auto-close timer ──────────────────────────────────────────────────────
    Timer {
        id: autoCloseTimer
        interval: 1500
        repeat:   false
        onTriggered: panel.visible = false
    }

    // ── Pill — sits just below the status bar, horizontally centred ───────────
    Rectangle {
        id: pill

        anchors.top:              parent.top
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.topMargin:        T.Theme.barMargin * 2

        width:  state.showPrompt ? 200 : 300
        height: state.showPrompt ? 44  : 54

        Behavior on width  { NumberAnimation { duration: T.Theme.animNormal; easing.type: Easing.OutCubic } }
        Behavior on height { NumberAnimation { duration: T.Theme.animNormal; easing.type: Easing.OutCubic } }

        radius:       14
        color:        Qt.rgba(
                          T.Theme.bg.r * 0.92,
                          T.Theme.bg.g * 0.92,
                          T.Theme.bg.b * 0.95,
                          0.96
                      )
        border.color: Qt.rgba(1, 1, 1, 0.08)
        border.width: 1
        clip:         true

        MouseArea { anchors.fill: parent }

        ColumnLayout {
            anchors.fill:    parent
            anchors.margins: 10
            spacing:         6

            // ── Password prompt ───────────────────────────────────────────────
            RowLayout {
                visible:          state.showPrompt
                Layout.fillWidth: true
                spacing:          7

                Rectangle {
                    Layout.fillWidth: true
                    height: 26; radius: 8
                    color: passField.activeFocus
                        ? T.Theme.pw(T.Theme.pal?.colors?.color4, 0.08)
                        : T.Theme.pw(T.Theme.pal?.colors?.color7, 0.07)
                    border.color: passField.activeFocus
                        ? T.Theme.pw(T.Theme.pal?.colors?.color4, 0.55)
                        : Qt.rgba(1, 1, 1, 0.09)
                    border.width: 1
                    Behavior on color        { ColorAnimation { duration: T.Theme.animFast } }
                    Behavior on border.color { ColorAnimation { duration: T.Theme.animFast } }

                    TextInput {
                        id: passField
                        anchors {
                            left: parent.left; right: parent.right
                            verticalCenter: parent.verticalCenter
                            leftMargin: 10; rightMargin: 10
                        }
                        echoMode:       TextInput.Password
                        color:          T.Theme.fg
                        selectionColor: T.Theme.pw(T.Theme.pal?.colors?.color4, 0.35)
                        font { family: T.Theme.fontFamily; pixelSize: 13; bold: true }

                        Text {
                            anchors.fill: parent
                            verticalAlignment: Text.AlignVCenter
                            text:    "password…"
                            color:   T.Theme.dimFg
                            opacity: 0.40
                            font:    passField.font
                            visible: passField.text.length === 0
                        }
                        Keys.onReturnPressed: _confirm()
                        Keys.onEnterPressed:  _confirm()
                        Keys.onEscapePressed: panel.visible = false
                    }
                }

                Rectangle {
                    implicitWidth:  runTxt.implicitWidth + 20
                    height: 26; radius: 8
                    color: runMa.pressed
                        ? T.Theme.pw(T.Theme.pal?.colors?.color4, 0.45)
                        : runMa.containsMouse
                            ? T.Theme.pw(T.Theme.pal?.colors?.color4, 0.35)
                            : T.Theme.pw(T.Theme.pal?.colors?.color4, 0.22)
                    border.color: T.Theme.pw(T.Theme.pal?.colors?.color4, 0.40)
                    border.width: 1
                    Behavior on color { ColorAnimation { duration: T.Theme.animFast } }

                    Text {
                        id: runTxt
                        anchors.centerIn: parent
                        text:  "Run"
                        color: T.Theme.color4
                        font { family: T.Theme.fontFamily; pixelSize: 13; bold: true }
                    }
                    MouseArea {
                        id: runMa; anchors.fill: parent
                        hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                        onClicked: _confirm()
                    }
                }
            }

            // ── Progress view ─────────────────────────────────────────────────
            ColumnLayout {
                visible:           !state.showPrompt
                Layout.fillWidth:  true
                Layout.fillHeight: true
                spacing: 8

                RowLayout {
                    Layout.fillWidth: true
                    spacing: 8

                    Rectangle {
                        width: 7; height: 7; radius: 3.5
                        color: state.hadError ? T.Theme.color1
                             : state.done     ? T.Theme.color2
                             :                  T.Theme.color4
                        Behavior on color { ColorAnimation { duration: T.Theme.animNormal } }
                        SequentialAnimation on opacity {
                            running: state.running && !state.done; loops: Animation.Infinite
                            NumberAnimation { to: 0.3; duration: 700; easing.type: Easing.InOutSine }
                            NumberAnimation { to: 1.0; duration: 700; easing.type: Easing.InOutSine }
                        }
                    }

                    Text {
                        text: state.done
                                ? (state.hadError ? "Update failed" : "Up to date")
                                : state.statusText
                        color: state.hadError ? T.Theme.color1
                             : state.done     ? T.Theme.color2
                             :                  T.Theme.fg
                        opacity: state.done ? 1.0 : 0.80
                        font { family: T.Theme.fontFamily; pixelSize: 13; bold: true }
                        Layout.fillWidth: true
                        elide: Text.ElideRight
                        Behavior on color   { ColorAnimation { duration: T.Theme.animNormal } }
                        Behavior on opacity { NumberAnimation { duration: T.Theme.animNormal } }
                    }

                    Text {
                        visible: !state.done
                        text:    Math.round(state.progress * 100) + "%"
                        color:   T.Theme.dimFg; opacity: 0.55
                        font { family: T.Theme.fontFamily; pixelSize: 11; bold: true }
                    }

                    Rectangle {
                        width: 20; height: 20; radius: 10
                        color: closeMa.containsMouse ? Qt.rgba(1, 1, 1, 0.10) : "transparent"
                        Behavior on color { ColorAnimation { duration: T.Theme.animFast } }
                        Text {
                            anchors.centerIn: parent; text: "✕"
                            color:   T.Theme.dimFg
                            opacity: closeMa.containsMouse ? 0.9 : 0.45
                            font { family: T.Theme.fontFamily; pixelSize: 9 }
                            Behavior on opacity { NumberAnimation { duration: T.Theme.animFast } }
                        }
                        MouseArea {
                            id: closeMa; anchors.fill: parent
                            hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                            onClicked: { autoCloseTimer.stop(); panel.visible = false }
                        }
                    }
                }

                // Progress track
                Rectangle {
                    Layout.fillWidth: true
                    height: 4; radius: 2
                    color: Qt.rgba(1, 1, 1, 0.07)

                    // Glow
                    Rectangle {
                        width:  parent.width * state.progress
                        height: parent.height + 4
                        anchors.verticalCenter: parent.verticalCenter
                        radius: parent.radius; color: "transparent"
                        Rectangle {
                            anchors.centerIn: parent
                            width: parent.width; height: 10; radius: 5
                            opacity: 0.22
                            color: state.hadError ? T.Theme.color1
                                 : state.done     ? T.Theme.color2
                                 :                  T.Theme.color4
                            Behavior on color { ColorAnimation { duration: T.Theme.animNormal } }
                        }
                        Behavior on width { NumberAnimation { duration: 400; easing.type: Easing.OutCubic } }
                    }

                    Rectangle {
                        width:  parent.width * state.progress
                        height: parent.height; radius: parent.radius
                        color:  state.hadError ? T.Theme.color1
                              : state.done     ? T.Theme.color2
                              :                  T.Theme.color4
                        Behavior on width { NumberAnimation { duration: 400; easing.type: Easing.OutCubic } }
                        Behavior on color { ColorAnimation  { duration: T.Theme.animNormal } }
                    }
                }
            }
        }
    }

    // ── Processes ─────────────────────────────────────────────────────────────
    Process {
        id: pacmanProcess
        stdout: SplitParser {
            onRead: function(line) {
                var m = line.match(/\((\d+)\/(\d+)\)/)
                if (m) state.progress = (parseInt(m[1]) / parseInt(m[2])) * 0.70
                var t = line.replace(/^\s+|\s+$/g, "")
                if (t.length > 0) state.statusText = t
            }
        }
        onExited: function(code) {
            if (code !== 0) {
                state.hadError   = true
                state.statusText = "Pacman failed"
            }
            state.progress   = 0.70
            state.statusText = "Flatpak…"
            flatpakProcess.running = true
        }
    }

    Process {
        id: flatpakProcess
        command: ["flatpak", "update", "-y"]
        stdout: SplitParser {
            onRead: function(line) {
                var t = line.replace(/^\s+|\s+$/g, "")
                if (t.length > 0) state.statusText = t
                var m = line.match(/(\d+)\/(\d+)/)
                if (m) state.progress = 0.70 + (parseInt(m[1]) / parseInt(m[2])) * 0.30
            }
        }
        stderr: SplitParser {
            onRead: function(line) {
                var t = line.replace(/^\s+|\s+$/g, "")
                if (t.length > 0) state.statusText = t
            }
        }
        onExited: function(code) {
            if (code !== 0) state.hadError = true
            state.progress = 1.0
            state.running  = false
            state.done     = true
            panel.updateFinished()
            if (!state.hadError) {
                notifyProcess.command = [
                    "notify-send",
                    "--app-name=System Update",
                    "--urgency=normal",
                    "--icon=system-software-update",
                    "System updated",
                    "Pacman and Flatpak are up to date."
                ]
                autoCloseTimer.start()
            } else {
                notifyProcess.command = [
                    "notify-send",
                    "--app-name=System Update",
                    "--urgency=critical",
                    "--icon=dialog-error",
                    "Update failed",
                    "One or more steps exited with an error."
                ]
            }
            notifyProcess.running = true
        }
    }

    Process {
        id: notifyProcess
        // command is set dynamically before running
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    function _shellQuote(s) {
        return "'" + s.replace(/'/g, "'\\''") + "'"
    }

    function _confirm() {
        if (passField.text.length === 0) return
        state.sudoPass   = passField.text
        passField.text   = ""
        state.showPrompt = false
        state.running    = true
        state.progress   = 0.0
        state.statusText = "Starting…"
        pacmanProcess.command = [
            "bash", "-c",
            "echo " + _shellQuote(state.sudoPass) +
            " | sudo -S -p '' pacman -Syu --noconfirm 2>&1"
        ]
        pacmanProcess.running = true
    }
}
