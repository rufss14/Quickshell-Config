import Quickshell
import QtQuick
import "modules"

// ── OverlayRoot ───────────────────────────────────────────────────────────────
// Panel host — no overlay window, no dim layer, no animations.
// Instantiates the panel windows so they register into the Panels singleton
// and are ready to be triggered from anywhere in the shell.
// ─────────────────────────────────────────────────────────────────────────────
QtObject {
    id: root

    property var screen  // passed in from the Variants delegate in shell.qml

    property var _updatePanel:    UpdatePanel    { screen: root.screen }
    property var _wallpaperPanel: WallpaperPanel { screen: root.screen }
}
